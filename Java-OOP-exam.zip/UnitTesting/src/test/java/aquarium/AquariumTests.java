package aquarium;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AquariumTests {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS Aquarium
    private Aquarium tank;
    private Fish fish;

    @Before
    public void setUp(){
        this.tank = new Aquarium("Tank", 1);
        this.fish = new Fish("Goldie");

    }
    @Test(expected = NullPointerException.class)
    public void shouldReturnExceptionForCreatingAquariumWithEmptyName(){

        Aquarium aquarium = new Aquarium("", 20);
    }

    @Test(expected = NullPointerException.class)
    public void shouldReturnExceptionForCreatingAquariumWithNullName(){

        Aquarium aquarium = new Aquarium(null, 20);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldReturnExceptionForCreatingAquariumWithZeroCapacity(){

        Aquarium aquarium = new Aquarium("null", -2);
    }

    @Test
    public void shouldreturnListOfFish(){
        Assert.assertEquals(0, tank.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionForFullCapacity(){
        tank.add(fish);
        tank.add(new Fish("asd"));
    }

    @Test
    public void shouldAddFishToTank(){
        tank.add(fish);

        Assert.assertEquals(1, tank.getCount());
    }

    @Test
    public void shouldRemoveFishToTank(){
        tank.add(fish);
        tank.remove("Goldie");

        Assert.assertEquals(0, tank.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldReturnExceptionForRemovingNonExistingFish(){

        tank.add(fish);
        tank.remove("Gosho");

    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldReturnExceptionForSellingNonExistingFish(){
        tank.add(fish);
        tank.sellFish("Gosho");

    }

    @Test
    public void shouldsetAvailabilityForSoldFish(){
        tank.add(fish);
        tank.sellFish("Goldie");

        Assert.assertFalse(fish.isAvailable());
    }

    @Test
    public void shouldReturnCorrectReport(){
        Aquarium aquarium = new Aquarium("NewTank", 10);


        aquarium.add(fish);
        aquarium.add(new Fish("Gosho"));

        String expected = String.format("Fish available at %s: %s, %s", aquarium.getName(), fish.getName(), "Gosho");
        String actual = aquarium.report();

        Assert.assertEquals(expected, actual);
    }
}

