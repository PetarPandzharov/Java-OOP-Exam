package aquarium.repositories;

import aquarium.models.decorations.Decoration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DecorationRepository implements Repository {

    private List<Decoration> decorations;

    public DecorationRepository(){

        this.decorations = Collections.unmodifiableList(new ArrayList<>());
    }
    @Override
    public void add(Decoration decoration) {
        decorations.add(decoration);
    }

    @Override
    public boolean remove(Decoration decoration) {
        return decorations.remove(decoration);
    }

    @Override
    public Decoration findByType(String type) {
        Decoration decoration;

        decoration = decorations.stream()
                .filter(d -> d.getClass().getSimpleName().equals(type))
                .findFirst()
                .orElse(null);
        return decoration;
    }

    public List<Decoration> getDecorations() {
        return Collections.unmodifiableList(decorations);
    }
}
