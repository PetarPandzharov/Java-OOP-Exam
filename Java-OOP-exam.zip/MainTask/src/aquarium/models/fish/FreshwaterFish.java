package aquarium.models.fish;

public class FreshwaterFish extends BaseFish {
    public FreshwaterFish(String name, String species, double price) {
        super(name, species, price);
        setSize(3);
        setSizeIncrease(3);
    }
}
